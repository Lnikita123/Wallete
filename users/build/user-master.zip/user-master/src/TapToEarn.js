import React from 'react';

const TapToEarn = ({ onTap, clicksToday }) => {
    return (
        <div className="tap-to-earn-container">
            <img src="/path/to/logo.png" alt="Logo" className="logo" />
            <div onClick={onTap} className="tap-area">
                <p>Clicks Today: {clicksToday}/100</p>
                <div className="emoji-animation">👍</div>
            </div>
        </div>
    );
};

export default TapToEarn;
