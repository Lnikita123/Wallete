import React, { useState, useEffect } from 'react';
import PollCreator from './PollCreator';
import Poll from './Poll';
import TapToEarn from './TapToEarn';
import axios from 'axios';
import Web3 from 'web3';
import { signInWithGoogle } from './firebase';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './App.css';

const API_URL = 'http://localhost:5000';

const App = () => {
  const [polls, setPolls] = useState([]);
  const [user, setUser] = useState(null);
  const [showLoginOptions, setShowLoginOptions] = useState(false);
  const [points, setPoints] = useState(0);

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      const user = JSON.parse(savedUser);
      setUser(user);
      setPoints(user.points);
    }
  }, []);

  useEffect(() => {
    const fetchPolls = async () => {
      try {
        const response = await axios.get(`${API_URL}/api/poll`);
        setPolls(response.data);
      } catch (error) {
        console.error('Error fetching polls:', error);
      }
    };

    fetchPolls();
  }, []);

  const handleCreatePoll = async (poll) => {
    if (!user) {
      toast.error('Please login to create a poll');
      setShowLoginOptions(true);
      return;
    }

    try {
      const response = await axios.post(`${API_URL}/api/poll`, { ...poll, userId: user._id });
      setPolls([...polls, response.data]);
      setPoints(user.points - 5);
      setUser(prevUser => ({ ...prevUser, points: user.points - 5 }));
      localStorage.setItem('user', JSON.stringify({ ...user, points: user.points - 5 }));
    } catch (error) {
      console.error('Error creating poll:', error);
      toast.error('An error occurred while creating the poll.');
    }
  };

  const handleVote = async (pollId, option) => {
    if (!user) {
      toast.error('Please login to vote');
      setShowLoginOptions(true);
      return;
    }

    try {
      const response = await axios.post(`${API_URL}/api/poll/vote`, {
        option: option.option,
        userId: user._id,
        pollId: pollId,
      });
      setPolls(polls.map(p => p._id === response.data.poll._id ? response.data.poll : p));
      setPoints(response.data.points);
      setUser(prevUser => ({ ...prevUser, points: response.data.points }));
      localStorage.setItem('user', JSON.stringify({ ...user, points: response.data.points }));
      toast.success(`Vote recorded successfully.`);
    } catch (error) {
      console.error('Error voting:', error);
      toast.error(error.response?.data?.error || 'An error occurred while recording your vote.');
    }
  };

  const handleTap = () => {
    if (!user) {
      toast.error('Please login to earn points');
      setShowLoginOptions(true);
      return;
    }

    axios.post(`${API_URL}/api/users/tap`, { userId: user._id })
      .then(response => {
        setUser(response.data);
        setPoints(response.data.points);
        localStorage.setItem('user', JSON.stringify(response.data));
      })
      .catch(error => {
        if (error.response && error.response.status === 400) {
          toast.error('Daily click limit reached for tap to earn');
        } else {
          console.error(error);
        }
      });
  };

  const handleGoogleLogin = async () => {
    try {
      const googleUser = await signInWithGoogle();
      const response = await axios.post(`${API_URL}/api/users/create`, { username: googleUser.email, phone: 'dummy-phone-number' });
      setUser(response.data);
      setPoints(response.data.points);
      localStorage.setItem('user', JSON.stringify(response.data));
      setShowLoginOptions(false);
    } catch (error) {
      console.error('Google login error:', error);
    }
  };

  const connectWallet = async () => {
    if (window.ethereum) {
      const web3 = new Web3(window.ethereum);
      try {
        await window.ethereum.enable();
        const accounts = await web3.eth.getAccounts();
        const response = await axios.post(`${API_URL}/api/users/create`, { username: accounts[0], phone: 'dummy-phone-number' });
        setUser(response.data);
        setPoints(response.data.points);
        localStorage.setItem('user', JSON.stringify(response.data));
        setShowLoginOptions(false);
      } catch (error) {
        console.error(error);
      }
    } else {
      alert('Please install MetaMask!');
    }
  };

  return (
    <div className="app-container">
      <ToastContainer position="top-center" />
      {!user && !showLoginOptions && (
        <button onClick={() => setShowLoginOptions(true)}>Login</button>
      )}
      {!user && showLoginOptions && (
        <div>
          <button onClick={handleGoogleLogin}>Login with Google</button>
          <button onClick={connectWallet}>Connect Wallet</button>
        </div>
      )}
      {user && (
        <>
          <h1>Welcome, {user.username}</h1>
          <PollCreator onCreatePoll={handleCreatePoll} />
          <div>
            <h2>All Polls</h2>
            {polls.map(poll => (
              <Poll key={poll._id} poll={poll} onVote={handleVote} userId={user._id} />
            ))}
          </div>
          <div>
            <h2>Your Points: {points}</h2>
            <TapToEarn onTap={handleTap} clicksToday={user.tapClicksToday} />
          </div>
        </>
      )}
    </div>
  );
};

export default App;
