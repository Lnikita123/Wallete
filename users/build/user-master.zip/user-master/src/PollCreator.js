import React, { useState } from 'react';

const PollCreator = ({ onCreatePoll }) => {
    const [pollTitle, setPollTitle] = useState('');
    const [options, setOptions] = useState([{ value: '' }]);

    const handleOptionChange = (index, event) => {
        const newOptions = options.slice();
        newOptions[index].value = event.target.value;
        setOptions(newOptions);
    };

    const handleAddOption = () => {
        setOptions([...options, { value: '' }]);
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        onCreatePoll({ title: pollTitle, options: options.map(opt => opt.value) });
        setPollTitle('');
        setOptions([{ value: '' }]);
    };

    return (
        <div>
            <h2>Create Your Own Poll</h2>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    value={pollTitle}
                    onChange={(e) => setPollTitle(e.target.value)}
                    placeholder="Poll Title"
                    required
                />
                {options.map((option, index) => (
                    <div key={index}>
                        <input
                            type="text"
                            value={option.value}
                            onChange={(e) => handleOptionChange(index, e)}
                            placeholder={`Option ${index + 1}`}
                            required
                        />
                    </div>
                ))}
                <button type="button" onClick={handleAddOption}>+</button>
                <button type="submit">Create Poll</button>
            </form>
        </div>
    );
};

export default PollCreator;
