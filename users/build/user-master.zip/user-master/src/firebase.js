// src/firebase.js
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
    apiKey: "AIzaSyC_QUtW65WUUytWgiWr856Z5elY7OLXsAc",
    authDomain: "telegrambot-d49a5.firebaseapp.com",
    projectId: "telegrambot-d49a5",
    storageBucket: "telegrambot-d49a5.appspot.com",
    messagingSenderId: "1023783076731",
    appId: "1:1023783076731:web:8688755f1bff74e93af3de",
    measurementId: "G-8S8BGZ44CP"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const provider = new GoogleAuthProvider();

const signInWithGoogle = async () => {
    try {
        const result = await signInWithPopup(auth, provider);
        const user = result.user;
        console.log('User info:', user);
        return user;
    } catch (error) {
        console.error('Error during sign-in:', error);
    }
};

export { auth, db, signInWithGoogle };
